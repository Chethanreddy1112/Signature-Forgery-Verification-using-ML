python Main.py
pause